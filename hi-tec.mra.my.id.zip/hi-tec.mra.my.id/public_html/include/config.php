<?php 
if(substr($_SERVER["REQUEST_URI"], -10) == "config.php"){header("Location:./");}; 
$data['mikhmon'] = array ('1'=>'mikhmon<|<starlinkpro','mikhmon>|>q6WTqp2bppyiqqA=');


$data['STARLINKPRO'] = array ('1'=>'STARLINKPRO!103.187.147.58:15155','STARLINKPRO@|@admin','STARLINKPRO#|#pKClp6CgqJqg','STARLINKPRO%starlinkpro.net','STARLINKPRO^starlinkpro.net','STARLINKPRO&RM','STARLINKPRO*30','STARLINKPRO(1','STARLINKPRO)','STARLINKPRO=10','STARLINKPRO@!@disable');